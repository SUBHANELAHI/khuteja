import java.util.*;
class Test{
public static void main(String[] args){
    List list = new ArrayList();
    list.add("2");
    list.add("cutshort");
    System.out.print(list.get(0) instanceof Integer);
    System.out.print(list.get(1) instanceof Object);
  }
}