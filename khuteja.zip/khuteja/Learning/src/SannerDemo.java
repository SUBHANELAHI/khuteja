import java.util.Scanner;

public class SannerDemo {
	
	
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int a;
		int b;
		int c;
		System.out.println("Enter 1st nmbr");
		a=sc.nextInt();
		//a=10;
		System.out.println("Enter 2nd nmbr");
		b=sc.nextInt();
		
		c=a+b;
		
		System.out.println("the answer is"+c);
		
		
	}
}
