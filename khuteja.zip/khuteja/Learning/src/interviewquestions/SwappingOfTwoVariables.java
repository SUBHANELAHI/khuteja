package interviewquestions;

public class SwappingOfTwoVariables {

	public static void main(String[] args) {
		int a=10;
		int b=20;
		// after swapping values must be a=20 b=10
		int temp;
		
		System.out.println("before Swapping a = "+a+" b = "+b);
		temp=a;
		a=b;
		b=temp;
		System.out.println("After Swapping a = "+a+" b = "+b);

	}

}
