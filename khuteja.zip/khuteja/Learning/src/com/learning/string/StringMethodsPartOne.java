package com.learning.string;

public class StringMethodsPartOne {

	public static void main(String[] args) 
	{
		String str="Hello World!";//string pool
		String strr = new String("Hello World!");//heap 
		String str1=" elahi ";
		
		int len= str.length();
		System.out.println("length of string is  "+len);
		
		char ch = str.charAt(6);
		System.out.println("char it given index is "+ch);
		
		int ind =str.indexOf('W');
		System.out.println("index value if char is "+ind);
		
		boolean strt = str.startsWith("Helo");
		System.out.println("statrs with ? "+strt);
		
		boolean end = str.endsWith("ld");
		System.out.println("ends with ? "+end);
		
		String upper = str.toUpperCase();
		System.out.println(upper);
		
		String lower = str.toLowerCase();
		System.out.println(lower);
		
		boolean emt = str.isEmpty();
		System.out.println("is Empty ? "+emt);
		
		boolean cont = str.contains("lo");
		System.out.println("is Contains ?"+cont);
		
		System.out.println(str1);
		
		String trm = str1.trim();
		System.out.println(trm);
		
		int cpm = strr.compareTo(str);
		System.out.println(cpm);
		
		boolean eq = strr.equals(str);//content compare
		System.out.println(eq);
		
		boolean eq1 = strr == str;// 
		System.out.println(eq1);
		
		String concat = str.concat(str1);
		System.out.println(concat);
	
		float hc = str.hashCode();
		System.out.println(hc);
		
		byte[] b = str.getBytes();
		System.out.println(b);
		
	}
}
