package com.learning.string;

public class StringBufferMethods {

	public static void main(String[] args) 
	{
		StringBuffer sb=new StringBuffer("Hello World!");
	
		int len = sb.length();
		System.out.println(len);
		
		sb.reverse();
		System.out.println(sb);
		
		StringBuffer s=new StringBuffer("Hello World!");
		s.append(2.20);
		System.out.println(s);
		
		StringBuffer s1=new StringBuffer("Hello ");
		s1.insert(6, 56);
		System.out.println(s1);
		
		StringBuffer s2=new StringBuffer("Hello World!");
		s2.delete(0,5);
		System.out.println(s2);
		
		StringBuffer s3=new StringBuffer("Hello World!");
		s3.deleteCharAt(3);
		System.out.println(s3);
		
		StringBuffer s4=new StringBuffer("Hello World!");
		s4.replace(6, len, "elahi");
		System.out.println(s4);
	}

}
