package com.learning.string;

public class ProgOne 
{
	public static void main(String args[]) 
	{
		//using Literal
		String str = "I Love My Country";
		
		//using new keyword
		String strg = new String("India is my country");
		
		System.out.println("Bakwass is "+ str + strg);
		
	}
}
