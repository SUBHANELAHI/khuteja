package com.learning.arrays;

public class LargEleInArray {

	public static void main(String[] args) {
		int a[] = { 1, 6, 12, 4 };
		// 0 1 2 3
		int larg = a[0];// 1 6 12

		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i]+" ");
			// a[i] = 1 6 12 4
			if (a[i] > larg) {// f t t f
				larg = a[i];
			}
		}
		System.out.println();
		System.out.println("largest element is : " + larg);
	}
}
