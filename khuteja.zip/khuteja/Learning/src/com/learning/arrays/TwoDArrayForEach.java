package com.learning.arrays;

public class TwoDArrayForEach {

	public static void main(String[] args) {
		int arr[][] = { { 1, 2, 3 }, { 3, 5, 4 }, { 8, 9, 7 } };
		for(int[] a: arr) {
			for(int j:a) {
				System.out.print(j+" ");
			}
			System.out.println();
		}
	}

}
