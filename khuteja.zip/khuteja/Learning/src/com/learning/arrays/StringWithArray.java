package com.learning.arrays;

import java.util.Scanner;

public class StringWithArray {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		 
		String str[]=new String[5];
		
		
		System.out.println("Enter Array elements : ");
		for(int i=0;i<str.length;i++) {
			str[i]=s.next();
		}
		System.out.println(" Inserted elements are : ");
		for(String aa:str) {
			System.out.print(aa+" ");
		}
		
		String st[]= {"elahi","loves","khuteja"};
		System.out.println("\n");
		for(int i=0;i<st.length;i++) {
			System.out.print(st[i]+" ");
		}
		System.out.println("\n");
		for(String a:st) {
			System.out.print(a+" ");
		}
		s.close();
	}

}
