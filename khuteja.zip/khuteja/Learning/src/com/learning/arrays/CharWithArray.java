package com.learning.arrays;

public class CharWithArray {

	public static void main(String[] args) {
		char ch[]= {'k','a','l','e'};
		System.out.println("Characters Are : ");
		for(int i=0;i<ch.length;i++) {
			System.out.print(ch[i]);
		}
		System.out.println();
		for(char c: ch) {
			System.out.print(c);
		}

	}

}
