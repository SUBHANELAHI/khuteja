package com.learning.arrays;

import java.util.Scanner;

public class StringWithArray1 
{
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		String arr[]=new String[3];
		
		System.out.println("Enter Array elements : ");
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.next();
		}
		
		System.out.println("elaments are : ");
		for(String a: arr) {
			System.out.print(a+" ");
		}
		
	}
}
