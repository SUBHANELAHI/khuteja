package com.learning.arrays;

public class AddOfArray {

	public static void main(String[] args) {
		int a1[] = { 3, 2, 5, 7 };
		int a2[] = { 5, 4, 7, 9 };

		for (int i = 0; i < a1.length; i++) {
			int a3 = a1[i] + a2[i];
			System.out.print(a3 + " ");
		}
	}
}