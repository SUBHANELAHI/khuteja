package com.learning.arrays;

public class ConvertingStringToCharacter 
{

	public static void main(String[] args) 
	{
		String str="hello";
		// without using array builtin function
		char ch[]=new char[str.length()];
		
		for(int i=0;i<ch.length;i++) {
			ch[i]=str.charAt(i);  //ch = 0=h(0),ch=1=e,ch=2=l, ch = 3 =l, ch=4=o
		}
		
		for(char cc : ch) {
			System.out.println(cc);
		}
		System.out.println();
		
		// using builtin function
		
		char chh[]=str.toCharArray();
		for(char c : chh) {
			System.out.println(c);
		}
	}
}
