package com.learning.arrays;

public class ArrayFirst {
	public static void main(String[] args) {
		int arr[] = { 1, 2, 3, 8, 6};
//					  0  1  2  3  4  
		for(int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+",");
		}
		
		System.out.println();
		int arr1[]=new int[5];
			arr1[0]=1;
			arr1[2]=2;
			arr1[1]=3;
			arr1[3]=8;
			arr1[4]=6;
			
		for(int i=0;i<arr1.length;i++) {
			System.out.print(arr1[i]+" ");
		}
			
		
	}
}
