package com.learning.loops.forloop;

public class RectanglePattern 
{
	public static void main(String[] args) 
	{
		int l=3;
		int b=3;
		
		for(int i=0;i<=l;i++) {
				
			for(int j=0;j<=b;j++) {
				System.out.print("* ");
			}
			System.out.println();
		}
	}

}
