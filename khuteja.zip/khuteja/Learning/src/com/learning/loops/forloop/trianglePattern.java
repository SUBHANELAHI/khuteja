package com.learning.loops.forloop;

public class trianglePattern {
	public static void main(String[] args) {
		int num1=1;
//		number patterns method 1

		int num2 = 5;
//		reverse number patterns method 1  
		for (int i = num2; i >= 1; i--) {
			for (int j = num2; j >= i; j--) {
				System.out.print(j + " ");
			}
			System.out.println();
		}
		System.out.println("----------");
		
//		reverse number patterns method 1 
		for (int i = num2; i >= 1; i--) {
			for (int j = i; j <= num2; j++) {
				System.out.print(j + " ");
			}
			System.out.println();
		}
	}
}
