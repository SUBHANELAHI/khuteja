package com.learning.loops.forloop;

public class NestedForLoopExaple {

	public static void main(String[] args) {
		// outer loop
		for (int i = 0; i < 3; i++) {

			System.out.println(i);// 0
			// inner loop
			for (int j = 0; j < 3; j++) {
				System.out.println( " " + j);// 0.t 1.t 2.t 3.f
			}
		}
	}
}
