package com.learning.loops.forloop;

public class FirstLoop 
{
	public static void main(String[] args) 
	{
		int i;
		for(i=1;i<=10;i++) {
			System.out.print(i+" ");  //0,1,
		}
		for(i=10;i>=0;i--) {
			System.out.println(i);
		}
	}
}
