package com.learning.loops.whileloop;

public class WhileOneToTen {

	public static void main(String[] args) {
		int n=1;
		while(n<=10) {//i<10
			System.out.println(n);
			n++;
		}

	}

}
