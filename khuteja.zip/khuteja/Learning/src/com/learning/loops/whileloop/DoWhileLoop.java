package com.learning.loops.whileloop;

public class DoWhileLoop {

	public static void main(String[] args) {

		/* syntax
			do{
				//code
			}
			while(condition)
		 */
		int n=1;
		do {
			System.out.println(n);
			n++;
		}while(n<=10);
		

	}

}
