package com.learning.oops.accesspecifiers;

public class A 
{
	public int a=10;
	protected int b=20;
	int c=30;
}
