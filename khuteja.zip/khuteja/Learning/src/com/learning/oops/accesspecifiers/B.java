package com.learning.oops.accesspecifiers;

public class B {
	private int p=10;
	private int q=20;
}
