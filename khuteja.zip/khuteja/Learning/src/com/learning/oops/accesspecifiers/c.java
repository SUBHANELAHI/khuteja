package com.learning.oops.accesspecifiers;

public class c {
	private int d=40;
	
	public static void main(String[] args) {
		A obj1 = new A();
		
		System.out.println(obj1.a);
		System.out.println(obj1.b);
//		System.out.println(obj1.c);
		System.out.println(obj1.c);
		
		c obj2=new c();
		System.out.println(obj2.d);
		
	}
	
	
}
