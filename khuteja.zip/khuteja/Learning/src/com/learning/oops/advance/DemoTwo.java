package com.learning.oops.advance;

public class DemoTwo {
	static int a=10;
	static void demoMethod() {
		System.out.println("hello world!");
	}
	public static void main(String[] args) {
		Abc abc= new Abc();
		System.out.println(abc.h);
		System.out.println(a);
		demoMethod();
	}
}
