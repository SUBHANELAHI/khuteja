package com.learning.oops.advance;

class InnerClassDemo {
	int a=10;
	class Inner{
		int b=20;
	}
	public static void main(String[] args) {
		InnerClassDemo icd = new InnerClassDemo(); 
			System.out.println(icd.a);
		
		InnerClassDemo.Inner i = icd.new Inner();	
			System.out.println(i.b);
			
	}
	
}
