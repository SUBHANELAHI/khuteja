package com.learning.oops.advance;

public class ProgramOfAreas {

	public static void main(String[] args) {
		Areas a=new Areas();
		Double areaOfCircle=a.areaOfCircle(5.6f);
		System.out.println(areaOfCircle);
		
	}

}
