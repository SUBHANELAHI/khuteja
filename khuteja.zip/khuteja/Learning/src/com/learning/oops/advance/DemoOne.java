package com.learning.oops.advance;
public class DemoOne
{
	public static void main(String[] args) 
	{
		Abc abc=new Abc();
		//this whole this object creation 
		//Abc->Class name abc->reference new->memory allocation Abc()->constructor
		
		System.out.println(abc.a);
	}
}
