package com.learning.oops.advance;

public class Abc {
	String a="bbgdsgk";
	String b="bdsgdsgbk";
	String c="bbgdsgdsgk";
	String d="bbdsgdsgsk";
	String e="bbgsgk";
	String f="bbdsgdsk";
	String g="bsdgdsgbk";
	String h="bsdgdsgbk";
	String i="bgsdgsgbk";
	String j="bbdsgsdgk";
	String k="sdagdsagk";
	String l="dagfsadg";
	
}
