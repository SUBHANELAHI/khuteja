package com.learning.oops.advance;

public class Areas {
	
	double areaOfCircle(float radius) {		
		final double PI=3.142;
		double area=PI*(radius*radius);
		return area;
	}
	
	float areaOfRectangle(float length,float breadth) {
		float area=length*breadth;
		return area;
	}
	
	float areaOfTriangle(float base,float hieght) {
		final float half=0.5f;
		float area= half*base*hieght;
		return area;
	}
	
	float areaOfSquare(float size) {
		float area=size*size;
		return area;
	}
	
	void areaOfSphere(double radius) {
		final double PI=3.142;
		double area = 4*PI*(radius*radius);
	}
	
	double areaOfCylinder(float height,float radius) {
		final double PI=3.142;
		double area = 2*PI*radius*(height+radius);
		return area;
	}
}
