package com.learning.oops.encapsulation;

public class EncapsulationMain {

	public static void main(String[] args) {
		EncapsulationDemo1 ed= new EncapsulationDemo1();
		ed.seta(10);
		System.out.println(ed.geta());

	}

}
