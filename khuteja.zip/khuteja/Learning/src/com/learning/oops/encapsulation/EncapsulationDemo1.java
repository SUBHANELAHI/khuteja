package com.learning.oops.encapsulation;

public class EncapsulationDemo1 
{
	// hiding of data by making data members as private
	private int a;
	private int b;
	
	private String pm_nmbr;
	
	// creating getter and setter methods 
	// --> by typing 
	// --> by generating (right click > source > generate getter ad setter method
	
	void seta(int a) {
		this.a=a;
	}
	int geta() {
		return a;
	}
	
	
}
