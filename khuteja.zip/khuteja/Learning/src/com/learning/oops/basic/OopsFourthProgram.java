package com.learning.oops.basic;
public class OopsFourthProgram {
	//field,entity,data member,instance variable
	int a=100;
	int b=20;
	int c;
	String s1="hai";
	String s2="hello";
	
	int add() {
		c=a+b;
		return c;
	}
	
	String str() {
		String s3 = s1.concat(s2);
		return s3;
	}
	
	char ch() {
		char a='a';
		return a;
	}
	
	boolean bool() {
		if(a>b) {
			return true;
		}
		return false;
	}
	public static void main(String[] args) 
	{
		OopsFourthProgram ofp = new OopsFourthProgram(); //ofb  --> referance variable
		
		System.out.println(ofp.add());
		System.out.println(ofp.str());
		System.out.println(ofp.ch());
		System.out.println(ofp.bool());
	}
}
