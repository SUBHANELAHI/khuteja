package com.learning.oops.basic;

public class StudentWithMethod {
	int rollno;
	String name ;
	char section;
	char sex;
	long phno;
	String address;
	void studentOne() {
		rollno=1;
		name="elahi";
		section='a';
		sex='m';
		phno=12346789;
		address="begaluru";
		System.out.println(rollno+" "+name+" "+section+" "+sex+" "+phno+" "+address);
	}
	
	public static void main(String[] args) {
		StudentWithMethod s= new StudentWithMethod();
		s.studentOne();
	}
}
