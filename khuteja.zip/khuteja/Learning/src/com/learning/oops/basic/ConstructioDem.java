package com.learning.oops.basic;
// parameterized constructor
public class ConstructioDem 
{
	
	ConstructioDem(String name , int roll_no, char sec) {
		System.out.println(name+" "+roll_no+" "+sec);
	}
	public static void main(String[] args) {
		System.out.println("student details Are : ");
		ConstructioDem c1 = new ConstructioDem("elahi",80,'a');
		ConstructioDem c2 = new ConstructioDem("khuteja",60,'a');
		
	}
}
