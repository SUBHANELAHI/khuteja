package com.learning.oops.basic;

import java.util.Scanner;

public class OopsSecondProgram {
	//fields
	int a;
	int b;
	int c;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		OopsSecondProgram osp = new OopsSecondProgram();
		System.out.println("enter a");
		osp.a=sc.nextInt();
		System.out.println("enter b");
		osp.b=sc.nextInt();
		osp.c=osp.a+osp.b;
		System.out.println(osp.c);
	}
}
