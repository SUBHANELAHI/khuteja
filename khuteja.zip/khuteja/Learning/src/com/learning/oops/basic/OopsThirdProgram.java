package com.learning.oops.basic;

public class OopsThirdProgram {
	//field || Entity
	int a=10; //
	int b=20;
	int c;
	//method 
	
	void addition() {
		c=a+b;
		System.out.print("the addition is ");
		System.out.println(c);
	}
	void sub() {
		c=b-a;
		System.out.print("the subtraction is ");
		System.out.println(c);
		
	}
	
	public static void main(String[] args) 
	{
		OopsThirdProgram otp = new OopsThirdProgram();
		otp.sub();
		otp.addition();
	}
}
