package com.learning.oops.basic;

import java.util.Scanner;



public class ParameterisedMethods 
{
	void addition(int a,int b) {
		int c=a+b;
		System.out.println("the sum is " +c);
	}	
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);	
		ParameterisedMethods pm = new ParameterisedMethods();
		System.out.println("enter a");
		int a=s.nextInt();
		System.out.println("enter b ");
		int b=s.nextInt();
		pm.addition(a,b);
		
		s.close();
	}
}
