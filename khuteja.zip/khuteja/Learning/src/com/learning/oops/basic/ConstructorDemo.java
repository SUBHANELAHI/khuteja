package com.learning.oops.basic;
// non parameterized or default constructor 
public class ConstructorDemo {
	ConstructorDemo(){
		System.out.println("This Is Constructor ");
	}
	
	public static void main(String[] args) {
		ConstructorDemo cd=new ConstructorDemo();
		
	}
}
