package com.learning.oops.basic;

public class StudentWithReference 
{
	int rollno;
	String name ;
	char section;
	char sex;
	long phno;
	String address;

	public static void main(String[] args) {
		StudentWithReference s1=new StudentWithReference();
		StudentWithReference s2=new StudentWithReference();
		s1.rollno=1;
		s1.name="elahi";
		s1.section='a';
		s1.sex='m';
		s1.phno=1234567890;
		s1.address="brooke field banglore";
		
		s2.rollno=2;
		s2.name="khuteja";
		s2.section='b';
		s2.sex='f';
		s2.phno=636673241;
		s2.address="coconut layout mysore";
		
		System.out.println(s1.rollno+" "+s1.name+" "+s1.section+" "+s1.sex+" "+s1.phno+" "+s1.address);
		System.out.println(s2.rollno+" "+s2.name+" "+s2.section+" "+s2.sex+" "+s2.phno+" "+s2.address);
		
	}
	
	
}
