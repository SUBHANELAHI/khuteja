package com.learning.oops.basic;

public class ThisDemo {
	
	int rollno;//instance variables
	String name;
	char sec;
	
	void studentDetails(int rollno,String name,char sec) {
		this.rollno = rollno;
		this.name = name;
		this.sec = sec;
	}
	
	
	
	public static void main(String[] args) {
		ThisDemo td = new ThisDemo();
		td.studentDetails(101, "elahi",	'a');
		System.out.println(td.rollno+" "+td.name+" "+td.sec);
	}
}
