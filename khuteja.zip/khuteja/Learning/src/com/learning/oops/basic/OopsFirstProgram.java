package com.learning.oops.basic;

public class OopsFirstProgram 
{
	//fields
	int a=10;
	int b=20; //  instance variables
	
	public static void main(String[] args) 
	{
		OopsFirstProgram ofp = new OopsFirstProgram();
		
		int c = ofp.a + ofp.b ;
		System.out.println("A is : "+ofp.a);
		System.out.println("B is : "+ofp.b);
		System.out.println("addition of a & b is : "+c);
	}
}
