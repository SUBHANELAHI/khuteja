package com.learning.oops.accesspecifores2;
import com.learning.oops.accesspecifiers.*;
public class X {
	public static void main(String[] args) {
		A ob = new A();
		System.out.println(ob.a);
//		System.out.println(ob.b);
//		System.out.println(ob.c);
	}
}
