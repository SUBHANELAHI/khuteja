package operators;

public class RelationalOperator {

	public static void main(String[] args) {
		int a = 10;// int(12344) float(12.33) double(12.2214341242342) char(abcd) boolean (0 or 1 )
		int b = 20;
		int x = 10;
		boolean c;

		c = a > b;
		System.out.println(c);

		c = a < b;
		System.out.println(c);

		c = (a >= x);
		System.out.println(c);

		c = (a != b);
		System.out.println(c);

		c = (a != x);
		System.out.println(c);

		// ==
		c = (a == x);
		System.out.println(c);
		
		c=(a==b);
		System.out.println(c);

	}

}
