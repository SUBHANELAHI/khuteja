package operators;

public class IncrementAndDecrementOperator 
{
	// used to increment or decrement value by 1
	public static void main(String []args) 
	{
		int x=2;

		x++;//post increment
		System.out.println(x);
		
		++x;//pre increment
		System.out.println(x);
		
		x--;//post decrement
		System.out.println(x);
		
		--x;//pre decrement
		System.out.println(x);
		
	}
}
