package operators;

public class OperatorDemo {

	public static void main(String[] args) {
		int a=10;
		int b=8;
		int d;
		d=10;
		int c;
		
		c=a+b;
		System.out.println("Addition Is "+c);
		
		c=a-b;
		System.out.println("Subtraction is "+c);
		
		c=a*b;
		System.out.println("Multiplication Is "+c);
		
		c=a/b;
		System.out.println("Division is "+c);

	}

}
