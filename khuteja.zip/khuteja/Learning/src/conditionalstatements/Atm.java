package conditionalstatements;
import java.util.*;
public class Atm {

	public static void main(String[] args) 
	{
		 Scanner atm=new Scanner(System.in);
		 
		 int card=1;
		 int pin=1212;
		 double amount=20306.12;
		 String name ="";
		 if(card==1) {
			 name = "elahi";
		 }
		 System.out.println("Welcom To Atm...");
		 System.out.println("insret ur card");
		 int myCard=atm.nextInt();
		 if(myCard==card) {
			 
			  System.out.println("Card Verified Successfully"+name);
			  
			  System.out.println("Enter Pin ");
			  int myPin=atm.nextInt();
			  if(myPin==pin) {
				  System.out.println("Pin Successfully Verified");
				  
				  System.out.println("Enter Amount to Withdraw ");
				  double myAmount=atm.nextDouble();
				  if(myAmount<amount) {
					  System.out.println("Withdraw sucessfull");
					  System.out.println("Available balance is:"+(amount-myAmount));
					  
					  
					  
				  }else {
					  System.out.println("in sufficient balance");
				  }
				  
				  
			  }else {
				  System.out.println("invalid pin");
			  }
			
		 }else {
			 System.out.println("invalid Card");
		 }	 
		 
		 atm.close();
	}

}
