package conditionalstatements;

import java.util.Scanner;

public class IfElseDemo {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		//Greatest Of 2 numbers
		System.out.println("Enter a ");
		int a=sc.nextInt();
		System.out.println("Enter b ");
		int b=sc.nextInt();
		
		if(a>b) {
			System.out.println("a is greatest");
		}
		else {
			System.out.println("b is greatest");
		}

	}

}
