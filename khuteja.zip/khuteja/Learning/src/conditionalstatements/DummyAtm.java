package conditionalstatements;

import java.util.Scanner;

public class DummyAtm {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int card = 1800;
		int pin=1412;
		double amount=25000;
		int myCard;
		
		System.out.println("Welcome to ATM");
		
		System.out.println("insert ur card");
		myCard=s.nextInt();
		if(myCard==card) {
			System.out.println("valid card");
			
			System.out.println("Enter your PIN");
			int myPin=s.nextInt();
			if(myPin==pin) {
				System.out.println("verification successfull");
				
				System.out.println("enter the amount");
				double myAmount=s.nextDouble();
				if(myAmount<=amount) {
					System.out.println("withdraw successfull");
					double bal;
					bal=amount-myAmount;
					System.out.println("the balance is "+bal);
				}
				else {
					System.out.println("insufficient balance");
				}
			}
			else {
				System.out.println("invalid pin");
			}
		}
		else {
			System.out.println("invalid card");
		}
	}
}
