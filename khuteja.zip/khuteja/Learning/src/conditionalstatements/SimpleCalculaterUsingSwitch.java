package conditionalstatements;
import java.util.Scanner;
public class SimpleCalculaterUsingSwitch {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		
		System.out.println("enter 2 nos");
		int a=s.nextInt();
		int b=s.nextInt();
		int c;
		
		System.out.println(" press 1 for addition \n press 2 for subtraction \n press 3 for multiplication \n press 4 for division");
		System.out.println("enter ur choice");
		int ch=s.nextInt();
		switch(ch) {
		case 1:
			c=a+b;
			System.out.println("answer is "+c);
		break;
		case 2:
			c=a-b;
			System.out.println("answer is "+c);
		break;
		case 3:
			c=a*b;
			System.out.println("answer is "+c);
		break;
		case 4:
			c=a/b;
			System.out.println("answer is "+c);
		break;
		default:
			System.out.println("invalid choice");
		}
		s.close();
		
		
		

	}

}
