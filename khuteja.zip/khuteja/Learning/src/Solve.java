class Solve{
public static void main(String args[]){
 int k = 5;
 if((k=2)==3){
 k += 5;
 }
 else{
 k += 7;
 }
 System.out.print(k);
}
}