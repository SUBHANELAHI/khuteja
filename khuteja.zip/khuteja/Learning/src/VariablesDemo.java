
public class VariablesDemo {

	public static void main(String[] args) {
		int a=10;
		int b=20;
		int c=a;
		System.out.println(a+" and "+b);
		System.out.println(c);
	}

}
