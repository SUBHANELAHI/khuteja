public class Demo{ 
public static void main(String[] arr){ 
 } 
public static void main(String arr){ 
 } 
}