
public class MyFirstProgram {
	public static void main(String[] args) {
		System.out.println("Hello World !");
		System.out.println(1 + 1 + "abcd");
		System.out.println("-----------------------------------------");
		System.out.println('a');
		
		System.out.print("this is");
		System.out.print("khuteja");
	}
}
